from django.apps import AppConfig


class PostgresqlAppConfig(AppConfig):
    name = 'postgresql_app'
