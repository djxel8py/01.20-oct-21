.. djvideomem documentation master file, created by
   sphinx-quickstart.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to djvideomem's documentation!
======================================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   howto
   pycharm/configuration
   users



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
