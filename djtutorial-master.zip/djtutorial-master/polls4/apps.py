from django.apps import AppConfig


class Polls4Config(AppConfig):
    name = 'polls4'
