from django.apps import AppConfig


class Polls3Config(AppConfig):
    name = 'polls3'
