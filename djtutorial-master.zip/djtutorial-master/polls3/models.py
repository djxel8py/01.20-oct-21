import datetime

from django.db import models
from django.utils import timezone

# Create your models here.

# from polls2.models import Question
# from polls2.models import Choice

