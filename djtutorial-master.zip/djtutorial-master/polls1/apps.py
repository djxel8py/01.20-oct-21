from django.apps import AppConfig


class Polls1Config(AppConfig):
    name = 'polls1'
