from django.apps import AppConfig


class Polls2Config(AppConfig):
    name = 'polls2'
