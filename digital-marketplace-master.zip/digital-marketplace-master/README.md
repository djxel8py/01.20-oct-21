<p align="center">
  <p align="center">
    <a href="https://justdjango.com/?utm_source=github&utm_medium=logo" target="_blank">
      <img src="https://assets.justdjango.com/static/branding/logo.svg" alt="JustDjango" height="72">
    </a>
  </p>
  <p align="center">
    The Definitive Django Learning Platform.
  </p>
</p>

# Django Digital Marketplace

This is a digital marketplace website built with Django. The website displays electronic products, focussing on e-book textbooks. Users can add and remove products to/from their cart, and purchase access to the solutions provided by each book. Payments are handled with Stripe.

This project is part of a course on [JustDjango](https://learn.justdjango.com).

## Setup process

1. Make sure you have a [Stripe](https://stripe.com/) account. You will need your test API keys which you can find on your dashboard.
2. Create a virtualenv with `virtualenv env`
3. Install dependencies with `pip install -r requirements.txt`

---

<div align="center">

<i>Other places you can find us:</i><br>

<a href="https://www.youtube.com/channel/UCRM1gWNTDx0SHIqUJygD-kQ" target="_blank"><img src="https://img.shields.io/badge/YouTube-%23E4405F.svg?&style=flat-square&logo=youtube&logoColor=white" alt="YouTube"></a>
<a href="https://www.twitter.com/justdjangocode" target="_blank"><img src="https://img.shields.io/badge/Twitter-%231877F2.svg?&style=flat-square&logo=twitter&logoColor=white" alt="Twitter"></a>

</div>
