/// <reference types="react-scripts" />

declare namespace NodeJS {
    export interface ProcessEnv {
        REACT_APP_PAYPAL_CLIENT_ID: string;
    }
}
