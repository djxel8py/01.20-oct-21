from django.conf.urls import *

# URL test patterns for django-cookieless. Use this file to ensure a consistent
# set of URL patterns are used when running unit tests. This test_urls
# module should be referred to by your test class.

urlpatterns = patterns(
    "django-cookieless.views",
    # Add url patterns here
)
