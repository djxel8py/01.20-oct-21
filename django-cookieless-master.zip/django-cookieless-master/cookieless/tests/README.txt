django-cookieless tests
=======================

Use cookieless.tests.settings to run this as a test dummy django application
to try out cookieless.

This directory also doubles as the location for the unit test suite
for cookieless.
