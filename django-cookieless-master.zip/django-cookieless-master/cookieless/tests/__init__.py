""" Tests for django-cookieless """

from cookieless.tests.unit_tests import *
from cookieless.tests.functional_tests import *
from cookieless.tests.signal_functional_test import *
