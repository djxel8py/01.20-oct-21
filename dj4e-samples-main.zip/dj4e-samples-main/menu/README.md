Notes
-----

Note double extend of base template


https://docs.djangoproject.com/en/3.0/ref/class-based-views/base/#templateview

