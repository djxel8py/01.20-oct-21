from django.apps import AppConfig


class UsermodelConfig(AppConfig):
    name = 'usermodel'
