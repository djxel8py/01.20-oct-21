from django.contrib import admin
from myarts.models import Article

# Register your models here.

admin.site.register(Article)
