from django.apps import AppConfig


class TracksConfig(AppConfig):
    name = 'tracks'
