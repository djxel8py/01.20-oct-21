from django.apps import AppConfig


class CrispyConfig(AppConfig):
    name = 'crispy'
