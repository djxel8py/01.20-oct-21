from django.apps import AppConfig


class UtilConfig(AppConfig):
    name = 'util'
