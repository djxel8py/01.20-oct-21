This is the source code to a youtube tutorial on building a blog with django and cassandra NoSQL Database.

Signup To Cassandra : https://dtsx.io/3lZYkrQ

Link To Youtube Video : https://youtu.be/JH24exA7-CA
