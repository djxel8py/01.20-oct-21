/Users/cfe/cloud_sql_proxy -instances=serverless-cfe:us-west1:serverless-django-db-instance-01=tcp:6543 -credential_file=/Users/cfe/Dev/serverless-django/db/key.json


# 5432