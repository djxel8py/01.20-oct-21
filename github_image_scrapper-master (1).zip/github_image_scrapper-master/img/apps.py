from django.apps import AppConfig


class ImgConfig(AppConfig):
    name = 'img'
