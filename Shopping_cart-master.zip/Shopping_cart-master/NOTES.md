# How to add an object to a manytomany field
https://docs.djangoproject.com/en/2.0/topics/db/examples/many_to_many/

# How to add *many* objects to a manytomany field
https://stackoverflow.com/questions/4959499/how-to-add-multiple-objects-to-manytomany-relationship-at-once-in-django

# Accepting payments with Stripe
https://stripe.com/docs/quickstart

# Styling forms
https://stripe.com/docs/stripe-js/elements/migrating

# Example credit card form
https://stripe.com/docs/stripe-js/elements/quickstart
