from django.contrib import admin

from .models import Profile, FriendRequest

admin.site.register(Profile)
admin.site.register(FriendRequest)