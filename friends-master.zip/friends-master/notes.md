# roadmap

accounts app
	--> users have friends
		--> many to many relationship with itself

models 
	- user
		--> id
		--> name
		-->	email
	- friend request
		--> id
		--> from_user
		--> to_user
		--> timestamp ( expiry date? )
