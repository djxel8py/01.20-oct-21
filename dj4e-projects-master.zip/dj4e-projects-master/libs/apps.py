from django.apps import AppConfig


class LibsConfig(AppConfig):
    name = 'libs'
