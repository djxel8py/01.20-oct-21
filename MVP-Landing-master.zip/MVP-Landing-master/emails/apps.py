from django.apps import AppConfig


class EmailsConfig(AppConfig):
    name = 'emails'
