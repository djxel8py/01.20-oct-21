# activate our virtual environment
pipenv shell