from django.apps import AppConfig


class BlobuiConfig(AppConfig):
    name = 'blobui'
