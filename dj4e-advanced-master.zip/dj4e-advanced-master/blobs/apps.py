from django.apps import AppConfig


class BlobsConfig(AppConfig):
    name = 'blobs'
