from django.apps import AppConfig


class MembershipsConfig(AppConfig):
    name = 'memberships'
