queryset order_by option - https://docs.djangoproject.com/en/2.0/ref/models/querysets/#django.db.models.query.QuerySet.order_by

model cleaning and validation - https://docs.djangoproject.com/en/2.0/ref/models/instances/#validating-objects

manytomanyfield accessing - https://docs.djangoproject.com/en/2.0/topics/db/examples/many_to_many/

convert timestamp (unix to readable) - https://coderwall.com/p/-uuawg/how-do-i-convert-a-unix-timestamp-to-human-readable-format-in-python

get_context_data (search for it on this page using CTRL+F) - https://docs.djangoproject.com/en/2.0/topics/class-based-views/generic-display/